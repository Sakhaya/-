#pragma once

unsigned get_num_thread();
void set_num_threads(unsigned T);